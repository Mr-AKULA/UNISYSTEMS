module.exports = {
  name: 'host',
  remotes: [],
  plugins: [],
};
