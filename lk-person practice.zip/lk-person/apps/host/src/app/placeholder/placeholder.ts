import {Component} from '@angular/core';

@Component({
  selector: 'placeholder-component',
  templateUrl: './placeholder.html',
})
export class PlaceholderComponent {}
