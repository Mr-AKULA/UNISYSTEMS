declare module 'dicts/Module';

declare module 'profile/Module';

declare module 'announcements/Module';

declare module 'currentcontrol/Module';

declare module 'middlecontrol/Module';

declare module 'contingent/Module';

declare module 'projecting/Module';

declare module 'disciplineworkload/Module';

declare module 'classroom/Module';

declare module 'publications/Module';

declare module 'persondepartment/Module';

declare module 'reportdesigner/Module';

declare module 'reportviewer/Module';

declare module 'cards/Module';

declare module 'payslip/Module';
