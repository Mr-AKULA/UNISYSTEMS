export enum KafedraFields {
  kafedraShortName = 'kafedraShortName',
  kafedraSName = 'kafedraSName',
  sName = 'sName',
  name = 'name',
  kafedraName = 'kafedraName',
  facultySName = 'facultySName',
}
