enum CommonStatusEnumList {
  Active = 1,
  Archived = 2,
  Closed = 3,
}

export const CommonStatusEnum = CommonStatusEnumList;
