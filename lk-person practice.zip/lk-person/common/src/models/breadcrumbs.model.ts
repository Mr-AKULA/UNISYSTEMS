import {BreadCrumbItem} from '@progress/kendo-angular-navigation';

export interface DisableBreadCrumbRoutes extends BreadCrumbItem {
  address?: string;
}