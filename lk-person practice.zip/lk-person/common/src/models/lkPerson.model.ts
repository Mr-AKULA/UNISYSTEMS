export class LKPerson {
  personId!: number;
  personExternalId!: string;
  fullName!: string;
  firstName!: string;
  lastName!: string;
  middleName!: string;
  login!: string;
  birthday!: Date;
  hasPps!: boolean;
}
