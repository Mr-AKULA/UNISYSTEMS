export class PublicationsNotification {
  unreadMyPublications!: number;
  unreadAllPublications!: number;
}
