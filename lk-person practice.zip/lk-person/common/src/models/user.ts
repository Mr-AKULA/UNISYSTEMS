export class User {
  nbf!: number;
  exp!: number;
  client_id!: string;
  role!: string[];
  user_login!: string;
  person_id!: string;
  aud!: string[];
}
