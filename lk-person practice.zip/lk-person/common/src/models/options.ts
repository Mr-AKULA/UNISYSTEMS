export const boolOptions = [
  {id: true, text: 'Да'},
  {id: false, text: 'Нет'},
];

export const dropdownOptions = [
  {id: 0, text: 'Нет'},
  {id: 1, text: 'Чтение'},
  {id: 2, text: 'Запись'},
];
