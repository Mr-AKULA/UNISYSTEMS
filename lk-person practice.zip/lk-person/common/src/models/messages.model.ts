export class Messages {
  rtl!: boolean;
  messages!: {[key: string]: object | string};
}
