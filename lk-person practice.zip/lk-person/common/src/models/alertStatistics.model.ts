export interface AlertStatistics {
  total: number;
  firstParametr: number;
  calculatedParametr: number;
}
